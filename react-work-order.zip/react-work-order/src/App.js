import React, {Component} from 'react';
import './App.css';
import {Scheduler} from "./scheduler/Scheduler";
import Inproduction from './scheduler/Inproduction';
 import '../node_modules/bootstrap/dist/css/bootstrap.css';
import User from './Production';

class App extends Component {

  
  render() {

  // return  <Scheduler/>;
   return  <User/>;

  }
}

export default App;
