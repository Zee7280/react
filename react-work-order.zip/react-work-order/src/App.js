import React, {Component} from 'react';
import './App.css';
import Scheduler from "./scheduler/Scheduler";
import Inproduction from './scheduler/Inproduction';
 import '../node_modules/bootstrap/dist/css/bootstrap.css';
import User from './Production';
import { BrowserRouter as Router,Route, Switch } from 'react-router-dom';

class App extends Component {

  
  render() {
    //return < Scheduler/>
    return (
    <Router>
      <Switch>
      <Route exact path="/admin"  component={Scheduler}/>  
      <Route exact path="/"  component={Scheduler}/>  
      </Switch>
    </Router>
 );}
}

export default App;
