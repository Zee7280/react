const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function(app) {
  app.use(
    '/api',
    createProxyMiddleware({
      target: 'http://localhost/my-app/react-work-order-php/api',
      changeOrigin: true,
    })
  );
};
