import React, {Component} from 'react';
import axios from "axios";
import {DayPilot, DayPilotQueue} from "daypilot-pro-react";

export class Queue extends Component {

  // menu = new DayPilot.Menu({
  //   items: [
  //     {
  //       text: "Edit...",
  //       onClick: args => {
  //         this.clickQueueEdit(args.source.data);
  //       }
  //     },
  //     {
  //       text: "-",
  //     },
  //     {
  //       text: "Delete",
  //       onClick: args => {
  //         this.clickDelete(args.source.data);
  //       }
  //     },
  //   ]
  // });

  durations = [
    {id: 60, name: "1 hour"},
    {id: 90, name: "1.5 hours"},
    {id: 120, name: "2 hours"},
    {id: 150, name: "2.5 hours"},
    {id: 180, name: "3 hours"},
    {id: 210, name: "3.5 hours"},
    {id: 240, name: "4 hours"},
    {id: 270, name: "4.5 hours"},
    {id: 300, name: "5 hours"},
    {id: 330, name: "5.5 hours"},
    {id: 360, name: "6 hours"},
    {id: 390, name: "6.5 hours"},
    {id: 420, name: "7 hours"},
    {id: 450, name: "7.5 hours"},
    {id: 480, name: "8 hours"},
  ];

  constructor(props) {
    super(props);

    this.state = {
      config: {
        contextMenu: this.menu,
        // onEventClick: args => {
        //   this.clickQueueEdit(args.e.data);
        // },
        onEventMove: async args => {
          const {data: item} = await axios.post("http://localhost/erp/public/react/api/work_order_move.php", {
            id: args.e.data.id,
            position: args.position
          });
          window.location.reload();

          if (args.external) {
            args.source.events.remove(args.e);
          }
        },
        onBeforeEventRender: args => {
          const duration = new DayPilot.Duration(args.data.start, args.data.end);
          args.data.html = "";
            console.log(args.data.priority);
            let color='';
            if(args.data.priority==1){
                color = 'red';
            }else if(args.data.priority==2){
              color = 'orange';
            }else if(args.data.priority==3){
                color = 'gray';
            }else{
              color='rgba(255, 255, 255, .5)';
            }
            //rgba(255, 255, 255, .5)
          args.data.areas = [
            {
              top: 11,
              right: 5,
              height: 20,
              width: 16,
              fontColor: "#999",
              symbol: "icons/daypilot.svg#minichevron-down-4",
              visibility: "Visible",
              action: "ContextMenu",
              menu: this.menu,
              style: "background-color:"+color+" ; border: 1px solid #aaa; box-sizing: border-box; cursor:pointer;"
            },
            {
              top: 0,
              left: 6,
              bottom: 0,
              width: 12,
              fontColor: "#999",
              symbol: "icons/daypilot.svg#move-vertical",
              style: "cursor: move",
              visibility: "Hover",
              toolTip: "Drag task to the scheduler",
              style: "background-color: "+color+"; overflow:hidden;text-overflow:ellipsis;whiteSpace:nowrap;width:150px;"

            },
            {
              top: 3,
              left: 20,
              text: "Art.Grp: "+args.data.text,
              style: "background-color: rgba(255, 255, 255, .5); overflow:hidden;text-overflow:ellipsis;whiteSpace:nowrap;width:150px;"

            }, 
            {
              top: 18,
              left: 20,
              text: "Meneg: "+args.data.Menge
            },
             {
              top: 30,
              left: 20,
              text: "Vorgang: "+args.data.VorID 
            },
            {
              top: 45,
              left: 20,
              text: "Vorgang: "+args.data.Artikelgruppe  
            },
            // {
            //   bottom: 3,
            //   left: 20,
            //   text: this.formatDuration(duration)
            // }
          ];
        }
      }
    };

  }

  async componentDidMount() {
     var url_string = window.location.href;
     var url = new URL(url_string);
   var token = url.searchParams.get("token");
//console.log(token);

    const {data: unscheduled} = await axios.get("http://localhost/erp/public/react/api/work_order_unscheduled_list.php?token="+token);
//console.log(unscheduled);
    const events = unscheduled.map(data => {
      return {
        ...data,
        duration: DayPilot.Duration.ofMinutes(data.duration),
        
      };
    });

    this.queue.update({
      events
    });

  }

  async clickDelete(item) {

    await axios.post("http://localhost/erp/public/react/api/work_order_delete.php", {
      id: item.id
    });

    this.remove(item.id);
  }

  get form() {
    const form = [
      {
        name: 'Description',
        id: 'text',
        type: 'text',
      },
      {
        type: 'select',
        id: 'duration',
        name: 'Duration',
        options: this.durations,
      },
       
    ];

    return form;
  }

  startEndFromMinutes(minutes) {
    const start = new DayPilot.Date("2000-01-01");
    const end = start.addMinutes(minutes);

    return {
      start,
      end
    };
  }

  async clickAdd(ev) {

    const form = this.form;

    const data = {
      text: "Task",
      duration: 60
    };

    const modal = await DayPilot.Modal.form(form, data);

    if (modal.canceled) {
      return;
    }

    const params = {
      ...modal.result,
      ...this.startEndFromMinutes(modal.result.duration)
    };

    const {data: created} = await axios.post("http://localhost/erp/public/react/api/work_order_unscheduled_create.php", params);

    this.add(created);

  }

  formatDuration(duration) {
    // const duration = DayPilot.Duration.ofMinutes(minutes);
    let result = duration.hours() + "h ";


    if (duration.minutes() > 0) {
      result += duration.minutes() + "m";
    }

    return result;
  }

  async clickQueueEdit(item) {
    const form = this.form;

    const data = {
      ...item,
      duration: new DayPilot.Duration(item.start, item.end).totalMinutes()
    };

    const modal = await DayPilot.Modal.form(form, data);

    if (modal.canceled) {
      return;
    }

    const params = {
      ...modal.result,
      ...this.startEndFromMinutes(modal.result.duration)
    }
//http://localhost/erp/public/react/api11
    const {data: updated} = await axios.post("http://localhost/erp/public/react/api/work_order_unscheduled_update.php", params);

    this.queue.events.update(updated);

  }

  add(item) {
    this.queue.events.add(item);
  }

  remove(id) {
    this.queue.events.remove(id);
  }

  render() {
    return (
      <div className={"queue"}>
        <button onClick={ev => this.clickAdd(ev)}>Add Task</button>
        <DayPilotQueue
          {...this.state.config}
          ref={component => this.queue = component && component.control}
        />
      </div>
    );
  }
}
