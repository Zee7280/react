import React,{useState,useEffect} from "react";
import axios from "axios";
import '../App.css';

const Inproduction = () => {


	const [usersData,setuser] = useState([]);

	useEffect(()=> {
		
	console.log('ddd');
	openProduction();
	
	
	},[]);
	
	const openProduction = async() => {

	var url_string = window.location.href;
     var url = new URL(url_string);
   var token = url.searchParams.get("token");
	  
		const result =await axios.get("http://localhost/ERP/api/production-Order?token="+token);
		setuser(result.data);
		console.log(result.data);
	
	}


	return(
	<>
				<hr/>
			<div><h4> Auftrage in order produktion</h4></div>
        <hr/>
		   <table style={{height:'500px',display:'block',overflowY:'auto'}} className="table table-striped table-bordered dt-responsive nowrap">
				<thead className="thead-light">
				<tr>
					<th class="tab-title"> Prio </th>
					<th class="tab-title"> Vorgang </th>
					<th class="tab-title"> Artikel</th>
					<th class="tab-title">Bezeichnung</th>
					<th class="tab-title"> Zusatz  </th> 
					<th class="tab-title-center">Gesamtmenge</th>
					<th class="tab-title-center"> start</th>
						<th class="tab-title-center"> ende</th>
				</tr>
				</thead>
					<tbody>
					
					{usersData.map((user,index) => (
					//const colller = user.USER_Prioritaet == 1 ? 'red' : (user.USER_Prioritaet == 2 ? 'yellow' : 'green')
						
					//const category = user.USER_Prioritaet ==2 ?'bb':'aa';
						
					
				
							<tr >
						 <th scope="row" style={{backgroundColor: user.USER_Prioritaet == 1 ? 'red' : (user.USER_Prioritaet == 2 ? 'orange' : 'green')}}> {user.USER_Prioritaet} </th>
						<td>{user.VorID }</td>
						<td>{user.Artikelgruppe}</td>
						<td>{user.Bezeichnung1}</td>
						<td>{user.Dimensionstext}</td>
						<td>{user.Menge}</td>
						<td>{user.start}</td>
						<td>{user.end}</td>
						</tr>

						))}

					</tbody>
	</table>

</>
		);
};

export default Inproduction;
