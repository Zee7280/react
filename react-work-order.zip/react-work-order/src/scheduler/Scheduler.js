import React, {Component} from 'react';
import {DayPilot, DayPilotScheduler} from "daypilot-pro-react";
import axios from "axios";
import {Queue} from "./Queue";
import queryString from 'query-string';
import Inproduction from './Inproduction';
import Openorder from './openOrder';

export class Scheduler extends Component {


  

  constructor(props) {
    super(props);

    this.state = {
      config: {
        eventHeight: 80,
        cellWidth: 4,
        dragOutAllowed: true,
        timeHeaders: [{groupBy: "Day"},{groupBy:"Month"}],//, {groupBy: "Hour"}
       // scale: "CellDuration",
        cellDuration: 20,
        showNonBusiness: false,
        treePreventParentUsage: true,
        days: DayPilot.Date.today().daysInYear(),
        startDate: DayPilot.Date.today().firstDayOfMonth(),
        timeRangeSelectedHandling: "Enabled",
        treeEnabled: true,
        onBeforeEventRender: args => {
          const text = args.data.text;
          const hours = new DayPilot.Duration(args.data.start, args.data.end).totalHours();
          args.priority=args.data.priority;
          args.data.backColor = args.data.color;
          args.data.html = `<div><span class='task-duration'>Bezeichnung</span>: ${text}<br><span class='task-duration'>Vorgang: ${args.data.VorID}</span><br><span class='task-duration'>Meneg: ${args.data.Menge}</span><br><span class='task-duration'>Artikel: ${args.data.Artikelgruppe}</span></div>`;
          let color='';
            if(args.data.priority==1){
                color = 'red';
            }else if(args.data.priority==2){
              color = 'orange';
            }else if(args.data.priority==3){
                color = 'green';
            }else{
              color='rgba(255, 255, 255, .5)';
            }


          args.data.areas = [
            {
              top: 11,
              right: 5,
              height: 16,
              width: 16,
              fontColor: "#999",
              symbol: "icons/daypilot.svg#minichevron-down-4",
              visibility: "Visible",
              action: "ContextMenu",
              menu: this.menu,
              style: "background-color: "+color+"; border: 1px solid #aaa; box-sizing: border-box; cursor:pointer;"
            },
          ];
        },
        onBeforeCellRender: args => {
          if (args.cell.isParent) {
            args.cell.properties.backColor = "#eee";
          }
        },
        onTimeRangeSelected: async args => {

          return false;
          const modal = await DayPilot.Modal.prompt("Create a new Schedule:", " Schedule");

          let dp = args.control;
          dp.clearSelection();
          if (!modal.result) {
            return;
          }

          let params = {
            text: modal.result,
            start: args.start,
            end: args.end,
            resource: args.resource,
          
          };

          const {data: result} = await axios.post("http://localhost/erp/public/react/api/work_order_create.php", params);

          dp.events.add(result);

        },
        onEventClick: async args => {
//http://localhost/erp/public/react/api12
          const {data: resources} = await axios.get("http://localhost/erp/public/react/api/work_order_resources_flat.php");
      const myArray = [{'id':'-1','name':'Done'},{'id':'0','name':'On the Way'}]
        console.log(resources);
          const form = [
            {
              id: 'text',
              name: 'Name',
            },
            {
              name: 'Start',
              id: 'start',
              dateFormat: 'd/M/yyyy h:mm tt',
              // disabled: true
            },
            {
              id: 'end',
              name: 'End',
              dateFormat: 'd/M/yyyy h:mm tt',
              // disabled: true
            },
            {
              type: 'select',
              id: 'resource',
              name: 'Resource',
              options: resources ,
               disabled: true
            },
             {
              type: 'select',
              id: 'status',
              name: 'Order Staus',
              options: myArray,
               // disabled: true
            },
          ];

          const modal = await DayPilot.Modal.form(form, args.e.data);

          if (modal.canceled) {
            return;
          }

          await axios.post("http://localhost/erp/public/react/api/work_order_update.php", modal.result);

           console.log("updating", modal.result);
          const data = {
            ...args.e.data,
             start: modal.result.start,
            end: modal.result.end,
            text: modal.result.text
          };

          this.scheduler.events.update(data);

        },
        onEventMove: async args => {
          var url_string = window.location.href;
          var url = new URL(url_string);
        var token = url.searchParams.get("token");
          console.log(args.e.data.Artikelgruppe);
          let params = {
            artikelgrup:args.e.data.Artikelgruppe,
            id: args.e.id(),
            start: args.newStart,
            end: args.newEnd,
            resource: args.newResource
          };    
         //  window.location.reload();
           //this.notify.Inproduction();
        
          await axios.post("http://localhost/erp/public/react/api/work_order_move.php?token="+token, params);

          if (args.external) {
            this.queue.remove(args.e.id());
          }

        },
        onEventResize: async args => {
          let params = {
             artikelgrup:args.e.data.Artikelgruppe,
            id: args.e.id(),
            start: args.newStart,
            end: args.newEnd,
            resource: args.e.resource()
          };
          await axios.post("http://localhost/erp/public/react/api/work_order_move.php", params);
        },
        onEventResizing: args => {
          let duration = new DayPilot.Duration(args.start, args.end);
          // if (duration.totalHours() > 8) {
          //   args.allowed = false;
          // }
        },
        onTimeRangeSelecting: args => {
          let duration = new DayPilot.Duration(args.start, args.end);
          // if (duration.totalHours() > 8) {
          //   args.allowed = false;
          // }
        },
        contextMenu: new DayPilot.Menu({
          items: [
            {
              text: "Edit...",
              onClick: args => {
                this.scheduler.onEventClick({e: args.source});
              }
            },
            {
              text: "-",
            },
            // {
            //   text: "Unschedule",
            //   onClick: args => {
            //     const e = args.source;
            //     this.clickUnschedule(e);
            //   }
            // },
            {
              text: "-",
            },
            // {
            //   text: "Delete",
            //   onClick: args => {
            //     const e = args.source;
            //     this.clickDelete(e);
            //   }
            // },
          ],
        })
      }
    };
  }

  componentDidMount() {
//console.log(this.props.location);
  //console.log(values) ;// "top"
  var url_string = window.location.href;
     var url = new URL(url_string);
   var token = url.searchParams.get("token");
   //alert(token);
    this.loadData(token);
    this.scheduler.scrollTo(DayPilot.Date.today());
  }
//https://betguard.getrentout.com/public/react
  async clickDelete(ev) {
    await axios.post("http://localhost/erp/public/react/api/work_order_delete.php", {
      id: ev.data.id
    });

    this.scheduler.events.remove(ev.data.id);
  }

  async clickUnschedule(ev) {
    const {data: item} = await axios.post("http://localhost/erp/public/react/api/work_order_unschedule.php", {
      id: ev.data.id
    });

    this.scheduler.events.remove(ev);
    this.queue.add(item);
  }

  async loadData(token) {
 

    const start = this.scheduler.visibleStart();
    const end = this.scheduler.visibleEnd();
    const promiseResources = axios.get(`http://localhost/erp/public/react/api/work_order_resources.php?token=`+token);
    const promiseEvents = axios.get(`http://localhost/erp/public/react/api/work_order_list.php?start=${start}&end=${end}`);
    const [{data: resources}, {data: events}] = await Promise.all([promiseResources, promiseEvents]);

    this.scheduler.update({
      resources,
      events
    });

  }










  render() {
    return (
      <div className={"container"}>
      <div className={"wrap"}>
        <div className={"left1"}>
          <Queue ref={component => this.queue = component}/>
        </div>

        <div className={"right"}>
          <DayPilotScheduler
            {...this.state.config}
            ref={component => this.scheduler = component && component.control}
          />
        </div>

      </div>
      <div className={"wrap"}>

        <div className={"left1"}>
         <Openorder/>
        </div>
        <div style={{marginLeft:'20px'}}className={"right"}>
         <Inproduction/>
        </div>

      </div>
        
       </div>
    );
  }
}
 


