import React,{useState} from 'react';
import '../node_modules/bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/js/bootstrap.bundle';
import axios from "axios";

class Production extends React.Component {
  constructor(props) {
    super(props);
    this.state = {value: 'coconut'};
    

   // this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    const result = axios.get("http://localhost/ERP/api/data?user="+ this.state.value);
    
         console.log('nn');
  }

  handleChange(event) {    this.setState({value: event.target.value});  }
  handleSubmit(event) {
    const result =  axios.get("http://localhost/ERP/api/data?user="+ this.state.value);
    //this.state1=result.data;
       //console.log(result.data);
       //console.log(result[0]);
    this.state = {
      firstLevel: Object.keys(result.id)[0],
      //secondLevel: Object.keys(props.options)[0][0]
    }
    alert('Your favorite flavor is: ' + this.state.value);
  
    event.preventDefault();
  }

 
  handleChange = event =>{
    this.setState({value:event.target.value})
  }

  render() {


    return (
<>
          
      <form onSubmit={this.handleSubmit}>
        <label>
          Pick your favorite flavor:
          <select value={this.state.value} onChange={this.handleChange}>            <option value="grapefruit">Grapefruit</option>
            <option value="lime">Lime</option>
            <option value="coconut">Coconut</option>
            <option value="mango">Mango</option>
          </select>
        </label>
        <input  type="submit" value="Submit" />
      </form>
      </>
    );

  }
}

export default Production;